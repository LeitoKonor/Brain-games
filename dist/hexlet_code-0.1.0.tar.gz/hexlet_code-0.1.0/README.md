### Hexlet tests and linter status:
[![Actions Status](https://github.com/LeitoKonor/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/LeitoKonor/python-project-49/actions)

<a href="https://codeclimate.com/github/LeitoKonor/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/3d5c45829a8b22e7408a/maintainability" /></a>

https://asciinema.org/a/BvNc7PTtrEyQYqR5wnaFPDQyh

https://asciinema.org/a/CctPMhfYi6K1kFS02w4MXnfuT

https://asciinema.org/a/FuVxrXFUIgCDEFob4MU9zkEo4